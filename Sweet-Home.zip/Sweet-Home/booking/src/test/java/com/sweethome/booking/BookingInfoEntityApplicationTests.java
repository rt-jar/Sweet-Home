package com.sweethome.booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingInfoEntityApplicationTests {

	@Test
	void contextLoads() {
	}

}
