package com.sweethome.booking.dal.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Data
@Entity
@Table(name = "booking")
public class BookingInfoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int bookingId;
    @Column(name = "fromDate")
    @JsonFormat
            (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date fromDate;
    @Column(name = "toDate")
    @JsonFormat
            (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date toDate;
    @Column(name = "aadharNumber")
    private String aadharNumber;
    @Column(name = "noOfRooms")
    private int noOfRooms;
    @Column(name = "roomNumbers")
    private String roomNumbers;
    @Column(name = "roomPrice")
    private int roomPrice;
    @Column(name = "transactionId")
    private int transactionId;
    @Column(name = "bookedOn")
    @JsonFormat
            (shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date bookedOn;

}
