package com.sweethome.booking.dal.repository;

import com.sweethome.booking.dal.model.BookingInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepository extends JpaRepository<BookingInfoEntity,Integer> {

}
