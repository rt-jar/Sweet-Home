package com.sweethome.booking.controller;

import lombok.Data;

@Data
public class PaymentDetails {
    private String paymentMode;
    private int bookingId;
    private String upiId;
    private String cardNumber;
}
