package com.sweethome.booking.controller;


import com.google.common.collect.Lists;
import com.sweethome.booking.clients.PaymentClient;
import com.sweethome.booking.dal.model.BookingInfoEntity;
import com.sweethome.booking.dal.repository.BookingRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/hotel")
public class BookingController {


    private final BookingRepository bookingRepository;
    private final PaymentClient paymentClient;

    public BookingController(final BookingRepository bookingRepository,
                             final PaymentClient paymentClient){
        this.bookingRepository = bookingRepository;
        this.paymentClient = paymentClient;
    }


    @PostMapping("/booking")
    public ResponseEntity<BookingInfoEntity> createBooking(@RequestBody BookingInfoEntity bookingInfoEntity) {
        bookingInfoEntity.setRoomNumbers(getRoomNumbers(bookingInfoEntity.getNoOfRooms()));
        bookingInfoEntity.setRoomPrice(1000 * bookingInfoEntity.getNoOfRooms() * getNoOfDate(bookingInfoEntity.getToDate(), bookingInfoEntity.getFromDate()));
        bookingInfoEntity.setBookedOn(new Date());
        BookingInfoEntity bookingInfo = bookingRepository.save(bookingInfoEntity);
        return new ResponseEntity<>(bookingInfo, HttpStatus.CREATED);
    }

    private int getNoOfDate(final Date toDate, final Date fromDate) {
        long diff = toDate.getTime() - fromDate.getTime();
        return (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
    }

    private String getRoomNumbers(final int noOfRooms) {
        return new Random().ints(noOfRooms, 1, 100).mapToObj(String::valueOf).collect(Collectors.joining(","));
    }


    @PostMapping("/booking/{bookingId}/transaction")
    public ResponseEntity makePayment(@PathVariable("bookingId") int bookingId, @RequestBody PaymentDetails paymentDetails) {
        final var paymentMode = paymentDetails.getPaymentMode() == null ? "" : paymentDetails.getPaymentMode().toUpperCase();
        if (Lists.newArrayList("CARD", "UPI").contains(paymentMode) ) {
            final BookingInfoEntity bookingInfoEntity = bookingRepository.findById(bookingId).orElse(null);
            if (bookingInfoEntity != null) {
                bookingInfoEntity.setTransactionId(paymentClient.createTransaction(paymentDetails));
                bookingRepository.save(bookingInfoEntity);
                return new ResponseEntity<>(bookingInfoEntity, HttpStatus.OK);
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid booking id.");
            }
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid mode of payment");
        }
    }

}
