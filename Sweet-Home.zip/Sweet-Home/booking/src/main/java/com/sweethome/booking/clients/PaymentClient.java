package com.sweethome.booking.clients;

import com.sweethome.booking.controller.PaymentDetails;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class PaymentClient {
    @Value("${payment.service.url:http://localhost:8083/payment}")
    private String paymentUrl;

    private final RestTemplate restTemplate = new RestTemplate();


    public int createTransaction(final PaymentDetails paymentDetails) {
        HttpEntity<PaymentDetails> request = new HttpEntity<>(paymentDetails);
        return restTemplate.postForObject(paymentUrl+ "/transaction", request, Integer.class);
    }
}
