package com.sweethome.payment.dal.repository;

import com.sweethome.payment.dal.model.TransactionDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<TransactionDetailsEntity, Integer> {
}
