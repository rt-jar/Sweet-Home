package com.sweethome.payment.controller;

import com.sweethome.payment.dal.model.TransactionDetailsEntity;
import com.sweethome.payment.dal.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
    private PaymentRepository paymentRepository;

    @PostMapping("/transaction")
    public ResponseEntity<Integer> createPayment(@RequestBody TransactionDetailsEntity transactionDetail) {
        final TransactionDetailsEntity entity = paymentRepository.save(transactionDetail);
        return new ResponseEntity<>(entity.getTransactionId(), HttpStatus.CREATED);
    }


    @GetMapping("/transaction/{transactionId}")
    public ResponseEntity<Integer> createPayment(@PathVariable("transactionId") int transactionId) {
        return paymentRepository.findById(transactionId)
                .map(entity -> new ResponseEntity<>(entity.getTransactionId(), HttpStatus.CREATED))
                .orElseGet(() -> new ResponseEntity<>(null, HttpStatus.NOT_FOUND));
    }



}
