package com.sweethome.payment.dal.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "transaction")
public class TransactionDetailsEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int transactionId;
    @Column(name ="paymentMode")
    private String paymentMode;
    @Column(name ="bookingId")
    private int bookingId;
    @Column(name ="upiId")
    private String upiId;
    @Column(name ="cardNumber")
    private String cardNumber;
}
